import java.util.*;
public class Pgm12_MapToList {
	public static void main(String args[])

	{

	Map<Integer,String> map = new HashMap<>();
    map.put(1, "S");
    map.put(2, "A");
    map.put(3, "N");
    map.put(4, "S");
    map.put(5, "K");
    map.put(6, "R");
    map.put(7, "U");
    map.put(8, "T");
    map.put(9, "I");

	List<Integer> key = new ArrayList(map.keySet());

	List<String> value = new ArrayList(map.values());

	System.out.println("Key :"+key);

	System.out.println("Values :"+value);

	}
}
