//Java Program to Concatenate Two Arrays
import java.util.Arrays;
import java.util.Scanner;
public class Pgm6_ConcatArray {
	public static void main(String args[])
	{
	    Scanner sc = new Scanner(System.in);
	    System.out.println("Enter the lenght of first array");
	    int alen = sc.nextInt();
	    System.out.println("Enter the lenght of second array");
	    int blen = sc.nextInt();
	    int [] a = new int[alen];
	    int [] b = new int[blen];
	    System.out.println("Enter the elements of first array");
	    for(int i=0;i<alen;i++)
	    {
	        a[i]=sc.nextInt();
	    }
	    System.out.println("Enter the elements of second array");
	    for(int i=0;i<blen;i++)
	    {
	        b[i]=sc.nextInt();
	    }
	    int len = alen+blen;
	    int[] ans = new int[len];
	    int pos=0;
	    for(int e:a)
	    {
	        ans[pos]=e;
	        pos++;
	    }
	    for(int e:b)
	    {
	        ans[pos]=e;
	        pos++;
	    }
	    System.out.println(Arrays.toString(ans));
	}
}
