
class God{
	int a,b;
	public God(int a, int b){
		this.a = a;
		this.b =b;
	}
	void add()
	{
		System.out.println("Parent Class Method Addition : "+(a+b));
	}
	
}
class Human extends God
{
	public Human(int a,int b){
		super(a,b);
	}
	void multiplication()
	{
		System.out.println("Child Class Multiplication : "+ a*b);
	}
}
public class Pgm30{
	public static void main(String args[])
	{
		Human obj = new Human(3,8);
		obj.add();
		obj.multiplication();
	}
}
