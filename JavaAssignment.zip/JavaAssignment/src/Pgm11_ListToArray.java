import java.util.ArrayList;

import java.util.Arrays;

import java.util.List;
public class Pgm11_ListToArray {
	public static void main(String args[])

	{

	ArrayList lang = new ArrayList<>();

	lang.add("Marathi");

	lang.add("Hindi");

	lang.add("English");

	System.out.println("CONVERT ARRAYLIST TO ARRAY");

	System.out.println("ArrayList : "+ lang);

	String[] arr = new String[lang.size()];

	lang.toArray(arr);

	System.out.println("Array : ");

	for(String i : arr)

	{

	System.out.print(i+" ,");

	}

	System.out.println();

	System.out.println("CONVERT ARRAY TO ARRAYLIST");

	String[] array = {"Get","the","future","you","want"};

	System.out.println("Array : "+Arrays.toString(array));

	List list1 = new ArrayList<>(Arrays.asList(array));

	System.out.println("List : "+ list1);

	}
}
