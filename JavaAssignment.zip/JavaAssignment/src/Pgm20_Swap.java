import java.util.Scanner;

public class Pgm20_Swap {
public static void main(String args[])
{
	Scanner sc = new Scanner(System.in);
	System.out.println("ENter two numbers");
	int a = sc.nextInt();
	int b = sc.nextInt();
	int temp;
	temp = a;
	a = b;
	b = temp;
	System.out.println(" "+ a+ " "+b);
	
}
}
