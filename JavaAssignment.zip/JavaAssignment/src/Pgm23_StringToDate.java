import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Pgm23_StringToDate {
public static void main(String args[]) throws ParseException
{
	String date = "5/11/2000";
	Date dateobj=new SimpleDateFormat("dd/MM/yyyy").parse(date);
	System.out.println(date+"    "+dateobj);
}
}
