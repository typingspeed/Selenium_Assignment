 

class A{
    public void print()
    {
        System.out.println("print from superclass A");
    }
} 
class Pgm27_Inheritance extends A {

 

    public void show()
    {
        System.out.println("Calling from subclass B ");
    }
    public static void main(String[] args) {
        A obj  = new Pgm27_Inheritance();        //

        obj.print();  //call method of parent class from main
        ((Pgm27_Inheritance)obj).show(); 

    }

 

}