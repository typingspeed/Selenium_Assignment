interface Sans{
   

	static void show() {
		// TODO Auto-generated method stub
		System.out.println("This is a demo method of interface");
	}
}
interface demo1{
    static void call() {
        System.out.println("Call me");
    }
}
public class Pgm28_MultipleInterface implements Sans {
	 public static void m1() {
	        System.out.println("Main class method");
	    }
	    public static void main(String[] args) {
	    //Java obj = new Java();
	    Sans.show();
	    demo1.call();
	    Pgm28_MultipleInterface.m1();
}
}