import java.util.Scanner;
public class Pgm8_FindValinArr {
	public static void main(String args[])

	{

	int[] arr = {1,2,3,4,5,6};

	System.out.println("Enter a number to find in an array");

	Scanner sc = new Scanner(System.in);

	int num = sc.nextInt();

	boolean find = false;

	for(int i=0;i<arr.length;i++)

	{

	if(arr[i]==num)

	{

	find = true;

	break;

	}

	}

	if(find==true)

	{

	System.out.println("Number found");

	}

	else

	{

	System.out.println("Number not found");

	}

	}
}
