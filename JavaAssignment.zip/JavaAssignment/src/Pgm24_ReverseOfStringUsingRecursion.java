
public class Pgm24_ReverseOfStringUsingRecursion {
public static void main(String args[])
{
	String str = "Sanskruti Paitwar";
	System.out.println(str);
	String reverse = reverseOfString(str);
	System.out.println("Reverse of String : " +reverse);
}

public static String reverseOfString(String str) {
	if(str.isEmpty())
	{
		return str;
	}
	else
	{
		char ch = str.charAt(0);
		return reverseOfString(str.substring(1))+ch;  //substring returns the string inclusive of the specified index
	}
}
}
