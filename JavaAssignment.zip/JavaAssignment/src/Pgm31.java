//abstract class AbstarctClass{
//	public void display()
//	{
//		System.out.println("This is the method of Abstract Class");
//	}
//}
//class Pgm31 extends AbstractClass {
//public static void main(String args[])
//{
//	Pgm31 obj = new Pgm31();
//	obj.display();
//}
//}
