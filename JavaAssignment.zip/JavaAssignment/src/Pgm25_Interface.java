interface demo{
	static void display()
	{
		System.out.println("I am the Display method of INTERFACE");
	}
}
public class Pgm25_Interface implements demo {
	public static void fun()
	{
		System.out.println("I am the method in MAIN METHOD");
	}
	public static void main(String args[])
	{
		Pgm25_Interface.fun();
		demo.display();
	}
}
