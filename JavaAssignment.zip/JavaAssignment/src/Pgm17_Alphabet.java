
public class Pgm17_Alphabet {
public static void main(String args[])
{char i;
	for( i ='A';i<='Z';++i)
	{
		System.out.print(" " +i);
	}
}
}
