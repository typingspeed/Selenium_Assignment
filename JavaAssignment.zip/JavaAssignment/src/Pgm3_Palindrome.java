import java.util.Scanner;

//Check Whether a string is Palindrome or Not
 public class Pgm3_Palindrome {
 public static void main(String args[])
 {
	 String a,b="";
	 Scanner sc = new Scanner(System.in);
	 System.out.println("Enter the string");
	 a = sc.nextLine();
	 int n = a.length();
	 for(int i = n-1;i>=0;i--)
	 {
		 b = b + a.charAt(i);
	 }
	 if(a.equalsIgnoreCase(b))
	 {
		 System.out.println("The given is palindrome");
	 }
	 else
	 {
		 System.out.println("The given is not palindrome");
	 }
 }
}
