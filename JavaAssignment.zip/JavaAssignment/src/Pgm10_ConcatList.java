import java.util.ArrayList;

import java.util.List;
public class Pgm10_ConcatList {
	public static void main(String args[])

	{

	List<String> list1 = new ArrayList<String>();

	List<String> list2 = new ArrayList<String>();

	list1.add("Hello");

	list2.add("Capgemini");

	List<String> joinList = new ArrayList<String>();

	joinList.addAll(list1);

	joinList.addAll(list2);

	System.out.println("List 1 : "+list1);

	System.out.println("List 2 : "+list2);

	System.out.println("Joined List : "+joinList);

	 

	}


}
