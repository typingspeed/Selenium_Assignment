class Parent{
	int a,b;
	public Parent(int a, int b){
		this.a = a;
		this.b =b;
	}
	void add()
	{
		System.out.println("Parent Class Method Addition : "+(a+b));
	}
	
}
class Child extends Parent
{
	public Child(int a,int b){
		super(a,b);
	}
	void multiplication()
	{
		System.out.println("Child Class Multiplication : "+ a*b);
	}
}
public class Pgm26_ParentChildInheritance{
	public static void main(String args[])
	{
		Child obj = new Child(3,8);
		obj.add();
		obj.multiplication();
	}
}
