package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class FlipkartPage {
	protected WebDriver driver;
	private By selling_price = By.xpath("//*[@id=\"app\"]/div[2]/div[14]/div[3]/div[3]/div[1]/div[1]/div[2]/div[2]/div/input");
	private By fee_structure = By.xpath("//*[@id=\"app\"]/div[1]/div/div[1]/ul/li[1]/a");
	private By search_for_product = By.name("q");
	private By phone_number = By.xpath("//*[@id=\"app\"]/div[2]/div[1]/div/div/div/div[1]/div/div/input");
	public FlipkartPage(WebDriver driver)
	{
		
		this.driver = driver;
	
	}
	public void phone_number_for_seller(String mobilenumber)
	{
		driver.findElement(phone_number).sendKeys(mobilenumber);
	}
	public void search_for_particular_product(String product)
	{
		driver.findElement(search_for_product).sendKeys(product);
	}
	public void fee_structure_link_click()
	{
		driver.findElement(fee_structure).click();
	}
	public void selling_price_input(String sp)
	{
		driver.findElement(selling_price).clear();
		driver.findElement(selling_price).clear();
		driver.findElement(selling_price).clear();
		driver.findElement(selling_price).sendKeys(sp);
		driver.findElement(selling_price).sendKeys(Keys.ENTER);
	}
}

