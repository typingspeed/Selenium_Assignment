package StepDefinitions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Demo {
	
	WebDriver driver = null;
	@Test
	public void first()
{
		String projectPath = System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver",projectPath+"/src/test/resources/drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://www.dice.com");
		driver.manage().window().maximize();
		driver.quit();
		}
	
	@Test
	public void second()
{
		String projectPath = System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver",projectPath+"/src/test/resources/drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://marketplace.eclipse.org/search/site/testng");
		driver.manage().window().maximize();
		driver.quit();
		}
}
/*
 *<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE suite SYSTEM "https://testng.org/testng-1.0.dtd">
<suite name="Suite">
  <test thread-count="5" name="Test">
    <classes>
      <class name="StepDefinitions.Demo"/>
    </classes>
  </test> <!-- Test -->
</suite> <!-- Suite --> */
 