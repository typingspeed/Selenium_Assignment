package StepDefinitions;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import io.cucumber.java.en.*;
import pages.FlipkartPage;
import pages.LoginPage;

public class Flipkart {
	WebDriver driver = null;
	FlipkartPage flipkart;
	//Scenario 1 START
	@Given("user opens flipkart website")
	public void user_opens_flipkart_website() {
		String projectPath = System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver",projectPath+"/src/test/resources/drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.flipkart.com/");
		
		driver.manage().window().maximize();
		Actions actions = new Actions(driver);
		Action sendEsc = actions.sendKeys(Keys.ESCAPE).build();
		sendEsc.perform();
	}
	
	@When("^user search for a (.*)$")
	public void user_search_for_a_product(String product) {
		driver.findElement(By.name("q")).sendKeys(product);
		
	}
	@Then("list of all the product is displayed")
	public void list_of_all_the_product_is_displayed() {
		driver.findElement(By.className("L0Z3Pu")).click();
	//	driver.findElement(By.className("_10UF8M _3LsR0e")).click();
		
		try {
		Thread.sleep(3000);
	} catch (InterruptedException e) {
		
		e.printStackTrace();
	}
		driver.close();
		driver.quit();
	}
	//Scenario 1 END
	//Scenario 2 START
	@When("user clicks on become a seller link")
	public void user_clicks_on_become_a_seller_link()
	{
		driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[1]/div[1]/div[2]/div[4]/a/span")).click();
	}
	@Then("the page opens")
	public void the_page_opens() throws InterruptedException
	{
		System.out.println("The Seller Page gets open");
		Thread.sleep(1000);

	}
	
	@Then("^user dials the (.*)$")
	public void user_dials_the_mobile_number(String mobilenumber) throws InterruptedException
	{
		//flipkart.phone_number_for_seller(mobilenumber);
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[2]/div[1]/div/div/div/div[1]/div/div/input")).sendKeys(mobilenumber);
		Thread.sleep(2000);
	}
	
	@And("clicks on Start Selling button")
	public void clicks_on_Start_Selling_button() throws InterruptedException
	{
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[2]/div[1]/div/div/div/div[2]/button")).click();
		Thread.sleep(2000);
		driver.close();
		driver.quit();
	}
	//Scenario 2 END
	
	//Scenario 3 START
	@And("^user enters the (.*) number$")
	public void user_enters_the_mobile_number(String mobile)
	{
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[2]/div[1]/div/div/div/div[1]/div/div/input")).sendKeys(mobile);
	}
	
	@Then("clicks on start selling button")
	public void clicks_on_start_selling_button() throws InterruptedException
	{
		//Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[2]/div[1]/div/div/div/div[2]/button")).click();
		Thread.sleep(2000);
		driver.close();
		//driver.quit();
		
	}
	
	//Scenario 3 END
	
	//Scenario 4 Start
	@Then("^user clicks on fee structure and enters the selling price (.*) then profit is displayed$")
	public void user_clicks_on_fee_structure(String sp) throws InterruptedException
	{
		flipkart = new FlipkartPage(driver);
		flipkart.fee_structure_link_click();
        Thread.sleep(2000);
		flipkart.selling_price_input(sp);
		Thread.sleep(1000);
		driver.close();
		driver.quit();
	}
	
	//Scenario 4END
	//Scenario 5 START
	
	
	@Given("User click on login page")
    public void user_click_on_login_page() throws InterruptedException {
		String projectPath = System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver",projectPath+"/src/test/resources/drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.flipkart.com/");
		
		driver.manage().window().maximize();
		
	}

    @When("^User enter (.*)$")
    public void user_enter_mobile(String mobile)throws InterruptedException {
//         driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[2]/div[1]/div[2]/div[3]/div/div/div/a")).click();

 

            driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
            WebElement mob =driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div/div[2]/div/form/div[1]/input"));
            mob.sendKeys(mobile);
            Thread.sleep(3000);
            driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div/div[2]/div/form/div[3]/button")).click();
            Thread.sleep(2000);
    }
    
    @Then("User will get successful login to flipkart home page")
    public void user_will_get_successful_login_to_flipkart_home_page() {
    System.out.println("User is logged in Successfully");
    driver.close();
    driver.quit();
}
    //Scenario 5 END
    
    //Scenario 6 START
    @When("user clicks on grocery")
    public void user_clicks_on_grocery()
    {
    	driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[2]/div/div/div[1]/a/div[2]")).click();
    }
    @Then("grocery page should open")
    public void grocery_page_should_open() throws InterruptedException
    {
    	Thread.sleep(2000);
    }
    
    @Then("user should be able to add item to basket")
    public void user_should_be_able_to_add_item_to_basket() throws InterruptedException
    {
    	driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[1]/div[1]/div[2]/div[3]/div[2]/div/div[2]/div[2]/div/div/div[1]/form/input")).sendKeys("421201");
    	driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[1]/div[1]/div[2]/div[3]/div[2]/div/div[2]/div[2]/div/div/div[1]/form/input")).sendKeys(Keys.ENTER);
    	
    	//driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div[5]/div/div/div/div/div[1]/div/div/div/div[2]/div/button/span")).click();
    	Thread.sleep(2000);
    	driver.close();
    	driver.quit();
    }
    
    //Scenario 6 END
    
    //Scenario 7 START
    
    
    @Then("user is on home page")
    public void user_is_on_home_page() throws InterruptedException
    {
    	 String reg=driver.getTitle();
         String str2="Online Shopping Site for Mobiles, Electronics, Furniture, Grocery, Lifestyle, Books & More. Best Offers!";
         if (reg.equals(str2)) {
             System.out.println("Title Verified for flipkart home page");
         }
         else
         {
             driver.navigate().back();
         }
            //driver.manage().timeouts().pageLoadTimeout(70, TimeUnit.SECONDS);
           Thread.sleep(3000);
           driver.close();
    }

    //Scenario 7 END
    
    //Scenario 8 STart
    
    @Then("user clicks on view all button")
    public void user_clicks_on_view_all_button()
    {
    	
      driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div[3]/div/div/div[1]/div/div/a")).click();
     
     
    }
    
    @Then("user is able to scroll down to see all the listed items on the page")
    public void user_is_able_to_scroll_down_to_see_all_the_listed_items_on_the_page() throws InterruptedException
    {
    	 JavascriptExecutor js = (JavascriptExecutor) driver;
         js.executeScript("window.scrollBy(0,250)", "");
         Thread.sleep(2000);
         driver.close();
    }
    
    //Scenario 8 END
    //Scenario 9 START
    @Then("user clicks on explore plus link")
    public void user_clicks_on_explore_plus_link() throws InterruptedException
    {
    	driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[1]/div[1]/div[2]/div[1]/div/a[2]")).click();
    	 Thread.sleep(2000);
    	JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,990)", "");
        Thread.sleep(2000);
        driver.close();
    	
    }
    
    //Scenario 9  END
    
    //Scenario 10 START
    
    @Then("user scrolls to bottom page and clicks on footer FAQ link")
    public void user_scrolls_to_bottom_page_and_clicks_on_footer_FAQ_link() throws InterruptedException
    {
    	Thread.sleep(2000);
    	JavascriptExecutor js = (JavascriptExecutor) driver;
    	   js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
    	   driver.findElement(By.xpath("//*[@id=\"container\"]/div/footer/div/div[3]/div[1]/div[2]/a[4]")).click();
    	   Thread.sleep(3000);
    	   driver.close();
    }
	
}
